# Iris Classification Project

Machine learning project for CodeAlpha Task 1 using Random Forest to classify Iris species.

## Files
- iris_classification.py
- iris_classification.ipynb
- Iris.csv
- requirements.txt

## How to Run
```
pip install -r requirements.txt
python iris_classification.py
```
